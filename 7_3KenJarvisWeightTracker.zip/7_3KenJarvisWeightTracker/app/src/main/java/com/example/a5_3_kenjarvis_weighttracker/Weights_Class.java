package com.example.a5_3_kenjarvis_weighttracker;

public class Weights_Class {

    private final String date;
    private final float weight;
    private int id;

    // Constructors
    public Weights_Class(int ID, String date, float weight) {
        this.id = ID;
        this.date = date;
        this.weight = weight;
    }

    public Weights_Class(String date, float weight) {
        this.date = date;
        this.weight = weight;
    }

    // Getters and setters for each attribute
    public String getDate() {
        return date;
    }

    public float getWeight() {
        return weight;
    }


    public int getID() {
        return id;
    }

}
