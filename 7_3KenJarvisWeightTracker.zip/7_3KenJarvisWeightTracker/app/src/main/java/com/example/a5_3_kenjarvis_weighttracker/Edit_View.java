package com.example.a5_3_kenjarvis_weighttracker;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class Edit_View extends AppCompatActivity {

    Weight_Database weight;
    User_Model user;

    // List to hold the IDs of selected rows
    List<CompoundButton> checkRow = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editview);

        try {
            // Initialize the view
            onInit();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    // Method to open main screen activity
    public void openMain(View view) {
        Intent intent = new Intent(this, Main_Screen.class);
        startActivity(intent);
    }

    // Initialize the view
    public void onInit() throws ParseException {
        // Initialize database and user
        weight = Weight_Database.getInstance(this);
        user = User_Model.getUserInstance();

        // Retrieve all weight entries
        List<Weights_Class> allEntry = weight.getAllWeights(user);

        // Get the table layout
        TableLayout table = findViewById(R.id.editTable);


        TableRow header = getTableRow();

        table.addView(header);

        // Populate table rows dynamically
        for (int i = 0; i < allEntry.size(); i++) {
            TableRow row = new TableRow(this);

            // Checkbox for selection
            CheckBox check = new CheckBox(this);
            check.setGravity(Gravity.CENTER);
            check.setPadding(10, 10, 10, 10);
            check.setId(allEntry.get(i).getID());

            // Set checkbox click listener
            check.setOnClickListener(v -> {
                if (((CompoundButton) v).isChecked()) {
                    checkRow.add((CompoundButton) v);
                } else {
                    checkRow.remove((CompoundButton) v);
                }
            });

            row.addView(check);


            TextView textC1 = new TextView(this);
            textC1.setText(allEntry.get(i).getDate());
            textC1.setTextSize(14);
            textC1.setBackgroundResource(R.color.white);
            textC1.setGravity(Gravity.CENTER_HORIZONTAL);
            textC1.setPadding(10, 10, 10, 10);
            row.addView(textC1);


            TextView textC2 = new TextView(this);
            textC2.setText(String.valueOf(allEntry.get(i).getWeight()));
            textC2.setTextSize(14);
            textC2.setBackgroundResource(R.color.white);
            textC2.setGravity(Gravity.CENTER_HORIZONTAL);
            textC2.setPadding(10, 10, 10, 10);
            row.addView(textC2);

            table.addView(row);
        }
    }

    @NonNull
    private TableRow getTableRow() {
        TableRow header = new TableRow(this);

        // Header column 1
        TextView headerC1 = new TextView(this);
        headerC1.setText(R.string.selection);
        headerC1.setBackgroundResource(R.color.white);
        headerC1.setGravity(Gravity.CENTER);
        headerC1.setPadding(10, 10, 10, 10);
        header.addView(headerC1);

        // Header column 2
        TextView headerC2 = new TextView(this);
        headerC2.setText(R.string.datee);
        headerC2.setBackgroundResource(R.color.white);
        headerC2.setGravity(Gravity.CENTER);
        headerC2.setPadding(10, 10, 10, 10);
        header.addView(headerC2);

        // Header column 3
        TextView headerC3 = new TextView(this);
        headerC3.setText(R.string.weightt);
        headerC3.setBackgroundResource(R.color.white);
        headerC3.setGravity(Gravity.CENTER);
        headerC3.setPadding(10, 10, 10, 10);
        header.addView(headerC3);
        return header;
    }

    public void delRow(View view) {
        for (CompoundButton a : checkRow) {
            weight.removeEntry(a.getId());
        }

        // Refresh the activity
        finish();
        overridePendingTransition(0, 0);
        startActivity(getIntent());
        overridePendingTransition(0, 0);
    }

    // Method to edit selected rows
    public void editRow(View view) {
        for (CompoundButton a : checkRow) {
            AlertDialog.Builder builder = new AlertDialog.Builder(Edit_View.this);
            final EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);

            builder.setView(input)
                    .setTitle("Edit Record")
                    .setMessage("What is the new weight??")
                    .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                        @SuppressLint("UnsafeIntentLaunch")
                        public void onClick(DialogInterface dialog, int which) {
                            float newWeight = Float.parseFloat(input.getText().toString());
                            weight.updateEntry(a.getId(), newWeight, user);

                            // Refresh the activity
                            finish();
                            overridePendingTransition(0, 0);
                            startActivity(getIntent());
                            overridePendingTransition(0, 0);
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }
}