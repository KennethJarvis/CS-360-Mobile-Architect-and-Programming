package com.example.a5_3_kenjarvis_weighttracker;

import android.telephony.SmsManager;

import java.util.ArrayList;

public class SMS {

    public static void sendLongSMS(String phoneNumber) {
        String message = "Great job!";
        SmsManager smsManage = SmsManager.getDefault();
        ArrayList<String> part = smsManage.divideMessage(message);
        smsManage.sendMultipartTextMessage(phoneNumber, null, part, null, null);
    }

}
