package com.example.a5_3_kenjarvis_weighttracker;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText username;
    EditText password;
    Button login;
    TextView message;
    User_Database db;
    User_Model validUser;
    Weight_Database weight;


    // Login success
    private void login(String user) {


        weight = Weight_Database.getInstance(this);

        // Instantiate the UserModel
        validUser = User_Model.getUserInstance();
        validUser.setUserName(user);
        validUser.setGoal(weight.getGoal(validUser));

        // Start main screen activity
        Intent intent = new Intent(this, Main_Screen.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements and databases
        username = findViewById(R.id.textUsername);
        password = findViewById(R.id.textPassword);
        login = findViewById(R.id.buttonLogin);
        message = findViewById(R.id.passwordMessage);
        db = User_Database.getInstance(this);


        login.setEnabled(true);

        // Login button click listener
        login.setOnClickListener(i -> {

            // Get username and password
            String username = MainActivity.this.username.getText().toString();
            String password = MainActivity.this.password.getText().toString();

            // Check if username exists
            boolean validUser = db.checkUserName(username);
            boolean validPass = db.checkUserPassword(username, password);

            if (validUser) {
                if (validPass) {
                    // Successful login
                    Toast.makeText(MainActivity.this, "Logged in", Toast.LENGTH_SHORT).show();
                    login(username);
                } else {
                    // Incorrect password
                    Toast.makeText(MainActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
                }
            } else {
                // User not recognized, ask for registration
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder
                        .setTitle("Not Recognized")
                        .setMessage("Register?")
                        .setIcon(R.drawable.ic_launcher_background)
                        .setPositiveButton("Yes", (dialog, which) -> {
                            // Insert new user
                            Boolean userAdded = db.insertUser(username, password);
                            if (userAdded) {
                                Toast.makeText(MainActivity.this, "Account added", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(MainActivity.this, "Account failed", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            }

        });
    }
}


