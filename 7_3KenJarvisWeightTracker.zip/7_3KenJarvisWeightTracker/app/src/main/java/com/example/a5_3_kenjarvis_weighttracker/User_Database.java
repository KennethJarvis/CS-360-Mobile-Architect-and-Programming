package com.example.a5_3_kenjarvis_weighttracker;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class User_Database extends SQLiteOpenHelper {

    private static final int version = 1;
    private static final String databaseName = "users.db";
    private static User_Database userDB;

    private User_Database(Context context) {
        super(context, databaseName, null, version);
    }

    // Singleton pattern
    public static User_Database getInstance(Context context) {
        if (userDB == null) {
            userDB = new User_Database(context);
        }
        return userDB;
    }

    // Create users table if not exists
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    // Drop and recreate users table
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists users");
        onCreate(db);
    }

    // Insert a new user into the database
    public Boolean insertUser(String userName, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", userName);
        values.put("password", password);
        long writeResult = db.insert("users", null, values);
        // Return true if the insertion was successful
        return writeResult != -1;
    }

    // Check if a username exists in the database
    public Boolean checkUserName(String userName) {
        SQLiteDatabase db = this.getReadableDatabase();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ?",
                new String[]{userName});
        // Return true if the cursor has at least one entry (username exists), false otherwise
        return cursor.getCount() > 0;
    }

    // Check if a username and password exists in the database
    public Boolean checkUserPassword(String userName, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?",
                new String[]{userName, password});
        // Return true if the cursor has at least one entry
        return cursor.getCount() > 0;
    }
}

