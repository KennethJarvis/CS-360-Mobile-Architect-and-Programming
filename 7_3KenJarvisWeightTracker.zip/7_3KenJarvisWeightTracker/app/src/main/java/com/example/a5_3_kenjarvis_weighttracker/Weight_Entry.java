package com.example.a5_3_kenjarvis_weighttracker;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.text.MessageFormat;
import java.util.Calendar;

public class Weight_Entry extends AppCompatActivity {

    protected EditText date;
    protected EditText weight;
    protected String Date;
    User_Model user;
    Weight_Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weightentry);

        // Initialize UI elements and databases
        date = findViewById(R.id.editWeightDate);
        weight = findViewById(R.id.editWeightWeight);
        user = User_Model.getUserInstance();
        db = Weight_Database.getInstance(this);

        // Date picker dialog setup
        date.setOnClickListener(v -> {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    Weight_Entry.this,
                    (view, year1, monthOfYear, dayOfMonth) -> {
                        // Set selected date in the EditText and store in Date variable
                        date.setText(MessageFormat.format("{0}-{1}-{2}", monthOfYear + 1, dayOfMonth, year1));
                        Date = year1 + "/" + (monthOfYear + 1) + "/" +
                                dayOfMonth;
                    },
                    year, month, day);
            datePickerDialog.show();
        });
    }

    // Method to open main form
    public void openMainForm(View view) {
        Intent intent = new Intent(this, Main_Screen.class);
        startActivity(intent);
    }

    // Method to handle save button click
    public void onSaveClick(View view) {
        // Get date and weight from EditText fields
        String date = this.date.getText().toString();
        String sWeight = weight.getText().toString();
        float weight;


        if (!date.isEmpty() && !sWeight.isEmpty()) {
            weight = Float.parseFloat(sWeight);
            Weights_Class entry = new Weights_Class(Date, weight);
            db.addEntry(entry, user);

        }

        // Go back to main screen
        Intent intent = new Intent(this, Main_Screen.class);
        startActivity(intent);
    }
}
