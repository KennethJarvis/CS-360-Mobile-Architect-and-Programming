package com.example.a5_3_kenjarvis_weighttracker;

public class User_Model {

    private static User_Model loggedUser;
    private String userName;
    private float goal = 0;
    private String SMS = "";

    // Private constructor
    private User_Model() {
    }

    // Singleton pattern
    public static User_Model getUserInstance() {
        if (loggedUser == null) {
            loggedUser = new User_Model();
        }
        return loggedUser;
    }

    // Getter and setter methods
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    // Getter and setter methods for goal
    public float getGoal() {
        return goal;
    }

    public void setGoal(float goal) {
        this.goal = goal;
    }

    // Getter and setter methods for SMS
    public String getSMS() {
        return SMS;
    }

    public void setSMS(String SMS) {
        this.SMS = SMS;
    }
}

