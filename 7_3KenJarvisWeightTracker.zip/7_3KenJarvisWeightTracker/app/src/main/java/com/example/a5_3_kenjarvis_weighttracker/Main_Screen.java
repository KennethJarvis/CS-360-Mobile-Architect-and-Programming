package com.example.a5_3_kenjarvis_weighttracker;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.util.List;

public class Main_Screen extends AppCompatActivity {

    Weight_Database weight;
    User_Model user;

    // Create options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainscreen);

        // Button to open weight edit view
        findViewById(R.id.buttonEditWeight);

        try {
            // Initialize the view
            onInit();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    // Handle options menu item click
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        openSettings();
        return false;
    }

    // Open settings activity
    public void openSettings() {
        Intent intent = new Intent(this, User_Settings.class);
        startActivity(intent);
    }

    // Open edit view activity
    public void openEdit(View view) {
        Intent intent = new Intent(this, Edit_View.class);
        startActivity(intent);
    }

    // Open weight entry activity
    public void openWeightForm(View view) {
        Intent intent = new Intent(this, Weight_Entry.class);
        startActivity(intent);
    }

    // Add new weight goal
    public void onNewGoal(View view) {
        User_Model user = User_Model.getUserInstance();
        Weight_Database db = Weight_Database.getInstance(this);

        AlertDialog.Builder builder = new AlertDialog.Builder(Main_Screen.this);
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);

        builder.setView(input)
                .setTitle("Enter New Goal Weight")
                .setMessage("Enter new weight:")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @SuppressLint("UnsafeIntentLaunch")
                    public void onClick(DialogInterface dialog, int which) {
                        float userGoal = Float.parseFloat(input.getText().toString());
                        user.setGoal(userGoal);
                        db.addGoal(user);


                        // Refresh the activity
                        finish();
                        overridePendingTransition(0, 0);
                        startActivity(getIntent());
                        overridePendingTransition(0, 0);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Initialize the view
    private void onInit() throws ParseException {
        // Initialize database and user
        weight = Weight_Database.getInstance(this);
        user = User_Model.getUserInstance();

        // Retrieve all weight entries
        List<Weights_Class> allEntry = weight.getAllWeights(user);

        // Get the table layout
        TableLayout table = findViewById(R.id.weight_table);

        // Create table header
        TableRow header = new TableRow(this);

        // Header column 1
        TextView headerC1 = new TextView(this);
        headerC1.setText(R.string.dateee);
        headerC1.setBackgroundResource(R.color.white);
        headerC1.setGravity(Gravity.CENTER);
        headerC1.setPadding(10, 10, 10, 10);
        header.addView(headerC1);

        // Header column 2
        TextView headerC2 = new TextView(this);
        headerC2.setText(R.string.weighttt);
        headerC2.setBackgroundResource(R.color.white);
        headerC2.setGravity(Gravity.CENTER);
        headerC2.setPadding(10, 10, 10, 10);
        header.addView(headerC2);

        // Header column 3
        TextView headerC3 = new TextView(this);
        headerC3.setText(R.string.weight_remaining);
        headerC3.setBackgroundResource(R.color.white);
        headerC3.setGravity(Gravity.CENTER);
        headerC3.setPadding(10, 10, 10, 10);
        header.addView(headerC3);

        table.addView(header);

        // Populate table rows dynamically
        for (int i = 0; i < allEntry.size(); i++) {
            TableRow row = new TableRow(this);
            TextView textC1 = new TextView(this);
            textC1.setText(allEntry.get(i).getDate());
            textC1.setTextSize(14);
            textC1.setBackgroundResource(R.color.white);
            textC1.setGravity(Gravity.CENTER_HORIZONTAL);
            textC1.setPadding(10, 10, 10, 10);
            row.addView(textC1);

            TextView textC2 = new TextView(this);
            textC2.setText(String.valueOf(allEntry.get(i).getWeight()));
            textC2.setTextSize(14);
            textC2.setBackgroundResource(R.color.white);
            textC2.setGravity(Gravity.CENTER_HORIZONTAL);
            textC2.setPadding(10, 10, 10, 10);
            row.addView(textC2);

            TextView textC3 = new TextView(this);
            float weightRemain = allEntry.get(i).getWeight() - user.getGoal();
            String stringWeightRemain = String.valueOf(weightRemain);

            textC3.setText(stringWeightRemain);
            textC3.setTextSize(14);
            textC3.setBackgroundResource(R.color.white);
            textC3.setGravity(Gravity.CENTER_HORIZONTAL);
            textC3.setPadding(10, 10, 10, 10);
            row.addView(textC3);

            table.addView(row);
        }
    }

}
