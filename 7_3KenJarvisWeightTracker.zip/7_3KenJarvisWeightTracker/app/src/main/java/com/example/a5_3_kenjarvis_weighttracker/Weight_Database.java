package com.example.a5_3_kenjarvis_weighttracker;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Weight_Database extends SQLiteOpenHelper {

    // Database version and name
    private static final int version = 1;
    private static final String database = "weights.db";
    private static Weight_Database weight;

    // Private constructor to enforce singleton pattern
    private Weight_Database(Context context) {
        super(context, database, null, version);
    }

    // Singleton pattern to ensure only one instance of WeightDB is created
    public static Weight_Database getInstance(Context context) {
        if (weight == null) {
            weight = new Weight_Database(context);
        }
        return weight;
    }

    // Create tables on database creation
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table weights(_ID INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, date text, weight float)");
        db.execSQL("create Table goals(username TEXT primary key, goal float)");
    }

    // Drop and recreate tables on database upgrade
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists weights");
        db.execSQL("drop Table if exists goals");
        onCreate(db);
    }

    // Add a new weight entry to the database
    public void addEntry(Weights_Class entry, User_Model user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues value = new ContentValues();

        value.put("username", user.getUserName());
        value.put("date", entry.getDate());
        value.put("weight", entry.getWeight());

        db.insert("weights", null, value);
    }

    // Remove a weight entry from the database
    public void removeEntry(Integer entryID) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("weights", "_id = ?", new String[]{String.valueOf(entryID)});
    }

    // Update a weight entry in the database
    public void updateEntry(int _id, float weight, User_Model _user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("username", _user.getUserName());
        values.put("weight", weight);

        db.update("weights", values, "_id = " + _id, null);
    }

    // Add or update user's goal in the database
    public void addGoal(User_Model _user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("username", _user.getUserName());
        values.put("goal", _user.getGoal());

        boolean goalSet = false;

        String Query = "Select * from goals";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(Query, null);

        if (cursor.moveToFirst()) {
            do {
                String username = cursor.getString(0);
                if (username.equals(_user.getUserName())) {
                    goalSet = true;
                    break;
                }
            } while (cursor.moveToNext());
        }

        if (!goalSet) {
            db.insert("goals", null, values);
        } else {
            db.updateWithOnConflict("goals", values, "username = ?",
                    new String[]{_user.getUserName()}, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    // Get user's goal from the database
    public float getGoal(User_Model _user) {
        SQLiteDatabase _db = this.getWritableDatabase();
        float goalSet = 0;

        String Query = "Select * from goals";
        @SuppressLint("Recycle") Cursor cursor = _db.rawQuery(Query, null);

        if (cursor.moveToFirst()) {
            do {
                String username = cursor.getString(0);
                if (username.equals(_user.getUserName())) {
                    goalSet = cursor.getFloat(1);
                    break;
                }
            } while (cursor.moveToNext());
        }

        return goalSet;
    }

    // Get all weight entries for a user from the database
    @SuppressLint("SimpleDateFormat")
    public List<Weights_Class> getAllWeights(User_Model _user) {
        List<Weights_Class> allEntry = new ArrayList<>();
        SQLiteDatabase _db = this.getWritableDatabase();

        Cursor cursor = _db.rawQuery("SELECT * FROM weights ORDER BY date", null);

        if (cursor.moveToFirst()) {
            do {
                String username = cursor.getString(1);
                if (username.equals(_user.getUserName())) {
                    int ID = cursor.getInt(0);
                    String date = cursor.getString(2);

                    @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
                    Date newDate;
                    String prettyDate = null;
                    try {
                        newDate = format.parse(date);
                        format = new SimpleDateFormat("MM/dd/yyyy");
                        prettyDate = format.format(newDate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    int userWeight = cursor.getInt(3);

                    Weights_Class newEntry = new Weights_Class(ID, prettyDate, userWeight);
                    allEntry.add(newEntry);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return allEntry;
    }

}
