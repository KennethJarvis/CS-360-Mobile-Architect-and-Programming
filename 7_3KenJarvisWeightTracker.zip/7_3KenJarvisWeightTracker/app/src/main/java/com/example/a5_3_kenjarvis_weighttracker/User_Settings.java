package com.example.a5_3_kenjarvis_weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class User_Settings extends AppCompatActivity {
    User_Model user;
    EditText phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usersettings);

        user = User_Model.getUserInstance();
        phone = findViewById(R.id.editTextPhone);
        phone.setText(user.getSMS());

    }

    public void openMain(View view) {

        phone = findViewById(R.id.editTextPhone);
        String sPhone = phone.getText().toString();

        user.setSMS(sPhone);

        Intent intent = new Intent(this, Main_Screen.class);
        startActivity(intent);
    }
}